#!/bin/bash

plink --bfile your_input_file --geno 0.01 --maf 0.01 --make-bed --out filtered_snps
plink --bfile filtered_snps --indep-pairwise 50 10 0.9 --out pruned_snps
plink --bfile filtered_snps --extract pruned_snps.prune.in --make-bed --out snps
